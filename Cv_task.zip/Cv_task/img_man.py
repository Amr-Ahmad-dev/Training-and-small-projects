import cv2
import numpy as np
img = cv2.imread('IMG-20261106-WA0002.jpg')

print (img.shape)
print (img)

def scale_image(image, scale):
    width = int(image.shape[1] * scale)
    height = int(image.shape[0] * scale)
    dim = (width, height)
    return cv2.resize(image, dim, interpolation=cv2.INTER_AREA)
def rotate_image(image, angle):
    (h, w) = image.shape[:2]
    center = (w // 2, h // 2)
    M = cv2.getRotationMatrix2D(center, angle, 1.0)
    return cv2.warpAffine(image, M, (w, h))
def translate_image(image, x, y):
    M = np.float32([[1, 0, x], [0, 1, y]])
    return cv2.warpAffine(image, M, (image.shape[1], image.shape[0]))

def save_image(image, filename):
    cv2.imwrite(filename, image)


if __name__ == "__main__":
    scaled_img = scale_image(img, 0.5)
    rotated_img = rotate_image(img, 45)
    translated_img = translate_image(img, 100, 50)
    for i, img in enumerate([scaled_img, rotated_img, translated_img]):
        save_image(img, f'output_{i}.jpg')

