# 🩺 Breast Cancer Diagnostic Classification: Multi-Model Benchmark

[![Python](https://img.shields.io/badge/Python-3.8%2B-blue.svg)](https://www.python.org/)
[![Scikit-Learn](https://img.shields.io/badge/Library-Scikit--Learn-F7931E.svg)](https://scikit-learn.org/)
[![Dataset](https://img.shields.io/badge/Dataset-Wisconsin%20Breast%20Cancer-red.svg)](#)
[![Accuracy](https://img.shields.io/badge/Best%20Accuracy-98.25%25-brightgreen.svg)](#)
[![Significance](https://img.shields.io/badge/Significance-Top%20Tier%20Project-gold.svg)](#)

## 📌 Project Overview
An applied machine learning project evaluating multiple tree and ensemble architectures on the Wisconsin Diagnostic Breast Cancer dataset. The project demonstrates an end-to-end clinical machine learning workflow: exploratory correlation analysis, pipeline construction, automated feature scaling, multi-metric performance auditing, and visual benchmarking.

---

## 🧬 Dataset Characteristics
- **Source**: UCI Machine Learning Repository / Scikit-Learn `load_breast_cancer`.
- **Instances**: 569 patients (212 Malignant, 357 Benign).
- **Features**: 30 numeric cytological features derived from digitized cell nuclei images (Radius, Texture, Perimeter, Area, Smoothness, Compactness, Concavity, Concave points, Symmetry, Fractal dimension).

---

## 🛠️ Pipeline Architecture
1. **Exploratory Correlation Analysis**:
   - Computes Pearson correlation matrix across all 30 features.
   - Visualizes collinear feature clusters using a 12x10 Seaborn heatmap.
2. **Pipelines with Automated Scaling**:
   - Encapsulates preprocessing and model inference inside `sklearn.pipeline.Pipeline`.
   - Applies `StandardScaler()` to prevent data leakage during train/test splits.
3. **Six-Model Competitive Tournament**:
   - **Decision Tree**: Baseline single-tree estimator.
   - **Random Forest**: Parallel bagging over randomized feature subsets.
   - **Extra Trees**: Extremely randomized trees with randomized split thresholds.
   - **AdaBoost**: Adaptive sequential boosting.
   - **Gradient Boosting**: Loss gradient residual regression trees.
   - **Hist Gradient Boosting**: Histogram-binned gradient boosting (optimized for continuous features).
4. **Comprehensive Diagnostic Metrics**:
   - Evaluates **Accuracy**, **Precision**, **Recall (Sensitivity)**, **F1-Score**, and **ROC-AUC**.
   - Generates a comparative performance barplot.

---

## 📊 Benchmark Results Summary
| Model | Accuracy | Precision | Recall | F1 Score | ROC AUC |
|---|---|---|---|---|---|
| **Hist Gradient Boosting** | **98.25%** | **0.9726** | **1.0000** | **0.9861** | **0.9984** |
| **Extra Trees** | **97.37%** | **0.9722** | **0.9859** | **0.9790** | **0.9941** |
| **AdaBoost** | **97.37%** | **0.9722** | **0.9859** | **0.9790** | **0.9892** |
| **Random Forest** | **96.49%** | **0.9589** | **0.9859** | **0.9722** | **0.9931** |
| **Gradient Boosting** | **95.61%** | **0.9583** | **0.9718** | **0.9650** | **0.9908** |
| **Decision Tree** | **93.86%** | **0.9315** | **0.9577** | **0.9444** | **0.9324** |

---

## 💻 Code Structure
- **Notebook**: [`breast_cancer_diagnostic_benchmark.ipynb`](./breast_cancer_diagnostic_benchmark.ipynb)
- **Cell Count**: 5 execution cells (150 lines of compact, high-density machine learning code)
- **Dependencies**: `scikit-learn`, `pandas`, `numpy`, `matplotlib`, `seaborn`

---

## 🚀 How to Run
```bash
pip install scikit-learn pandas numpy matplotlib seaborn
jupyter notebook breast_cancer_diagnostic_benchmark.ipynb
```
